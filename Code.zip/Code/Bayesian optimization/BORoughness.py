"""
Evaluates the surface of the electrode using the solution u at a time instant
"""

from fenics import *
from boxfield import *
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np

def CVD(u):
    
    # Mesh dimension and size
    lox= 200
    loy= 100
    nx, ny = 400, 200  
    
    xi_t, w_t, phi_t = u.split(deepcopy=True)
    u_box = FEniCSBoxField(xi_t, (nx, ny))
    x = u_box.grid.coor[X]
    delx = x[1] - x[0]
    y = u_box.grid.coor[Y]
    dely = y[1] - y[0]
    delxy=delx*dely
    
    # Iterate over 2D mesh points (i, j)
    Usumz=np.zeros((1,u_box.values.shape[1]))
    
    for j in range(u_box.values.shape[1]): # Y direction
        Usumz[0,j]=np.sum(u_box.values[:,j])
        
    # total state of charge
    cellarea=2*abs(x[-1]-x[0])*abs(y[-1]-y[0]) # cellarea
    soc=np.sum(Usumz)*delxy/cellarea
    
    # valley level
    val=np.min(Usumz)*delx
    
    # dendrite level    
    den=np.max(Usumz)*delx
    
    return [soc,val,den]

