"""
Optimizes the objective function using Bayesian Optimization.
The optimal parameters are printed and saved.
"""

from fenics import *
from datetime import datetime
import matplotlib.pyplot as plt
from BOenv import phenv
import numpy as np 
import scipy.io
from ax import optimize

# Start message
print("Started at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))

# selected Parameters (nominal normalized values:)
#S1_normal = 1000000 
S2_normal = 1.19    
dv_normal= 5.5 
#Ls_normal= 0.001 
#L_normal= 6.25 
#el_normal=2.631
#c0_normal=1.0/14.89
M0_normal=317.9
#kappa_normal= 0.3 
#W_normal=2.4 
#es_normal=-13.8

# Feasible parameters range
Deltapercent=50

# trade-off in cost: Lam*ro-(1-Lam)ch
#Lam=1  #Dendrite inhibition
Lam=0   #fast charging


# Bayesian optimization
best_parameters, best_values, experiment, model = optimize(
        parameters=[
#          {
#            "name": "S1",
#            "type": "range",
#            "bounds": [S1_normal - S1_normal*Deltapercent/100, S1_normal + S1_normal*Deltapercent/100],
#          },
          {
            "name": "S2",
            "type": "range",
            "bounds": [S2_normal - S2_normal*Deltapercent/100, S2_normal + S2_normal*Deltapercent/100],
          },
          {
            "name": "dv",
            "type": "range",
            "bounds": [dv_normal - dv_normal*Deltapercent/100, dv_normal + dv_normal*Deltapercent/100],
          },
#          {
#            "name": "Ls",
#            "type": "range",
#           "bounds": [Ls_normal - Ls_normal*Deltapercent/100, Ls_normal + Ls_normal*Deltapercent/100],
#          },
#          {
#            "name": "L",
#            "type": "range",
#           "bounds": [L_normal - L_normal*Deltapercent/100, L_normal + L_normal*Deltapercent/100],
#          },
#          {
#            "name": "el",
#            "type": "range",
#            "bounds": [el_normal - el_normal*Deltapercent/100, el_normal + el_normal*Deltapercent/100],
#          },
#          {
#            "name": "c0",
#            "type": "range",
#            "bounds": [c0_normal - c0_normal*Deltapercent/100, c0_normal + c0_normal*Deltapercent/100],
#          },
          {
            "name": "M0",
            "type": "range",
            "bounds": [M0_normal - M0_normal*Deltapercent/100, M0_normal + M0_normal*Deltapercent/100],
          },
#          {
#            "name": "kappa",
#            "type": "range",
#            "bounds": [kappa_normal - kappa_normal*Deltapercent/100, kappa_normal + kappa_normal*Deltapercent/100],
#          },
#          {
#            "name": "W",
#            "type": "range",
#            "bounds": [W_normal - W_normal*Deltapercent/100, W_normal + W_normal*Deltapercent/100],
#          },
#            {
#                "name": "es",
#                "type": "range",
#                "bounds": [es_normal + es_normal*Deltapercent/100, es_normal - es_normal*Deltapercent/100],
#                },
          
        ],
        # Booth function
        evaluation_function=lambda p: phenv(p,Lam),
        minimize=True,
        total_trials=30
    )


# solution
print(f'best_parameters={best_parameters}')

# End message
print("Completed at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))

# save mat files
matdic = {"best_parameters": best_parameters}
scipy.io.savemat(f"BOpars_output.mat", matdic)

