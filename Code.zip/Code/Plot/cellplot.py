"""
Plots the order variable in the half cell at a time instant
"""

from fenics import *
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np 

# Start message
print("Started at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))

# Mesh dimension and size
lox= 200
loy= 100
nx, ny = 400, 200

# Mesh and function space
mesh = RectangleMesh(Point(0, 0), Point(lox, loy), nx, ny)
P1 = FiniteElement('P', triangle, 1)
V = FunctionSpace(mesh, MixedElement([P1,P1,P1]))

# Trial and  test functions
v_1, v_2, v_3 = TestFunctions(V)

# solutions at previous and current times
u = Function(V)                 # current time
u_n = Function(V)               # previous


# Load the solution
input_file = HDF5File(mesh.mpi_comm(), "u0.h5", "r")
input_file.read(u, "solution")
input_file.close()
u_old =u
   
#plot
xi_t, w_t, phi_t = u_old.split()
plt.figure(1)
cbar1=plt.colorbar(plot(xi_t), ticks=[0, 0.5, 1], orientation='horizontal')
cbar1.ax.tick_params(labelsize=15)
plt.xlabel(r'$x(\mu m)$',fontsize=15)
plt.ylabel(r'$y(\mu m)$',fontsize=15)
plt.title(r'Phase order $\zeta$',fontsize=15)

# output plots
plt.figure(1)
plt.savefig(f'aplot.eps',format='eps')

# End message
print("Completed at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))


