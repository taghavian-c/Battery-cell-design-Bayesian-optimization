% Calculates the descriptors.

clear
clc
%close all

zetamax=0.7;
zetamin=0.3;
phi_e=-0.45;

%______valley
phi1=-0.5;
phi0=-0.3;
%______tip
% phi1=-0.6;
% phi0=-0.1;

% % Linear boundary conditions:
% phi1=phi_e*(zetamax);
% phi0=phi_e*(zetamin);

% solve the two-point boundary problem:
xmesh=linspace(zetamin,zetamax,10^5);
solinit = bvpinit(xmesh,@guess);
sol=bvp5c(@bvpfcn,@bcfcn,solinit);
x1=length(xmesh)/2;
x2=length(xmesh)/2+1;
solnim=sol.y(1,x1); % d^phi

% plot:
% hold on
% plot(sol.x,sol.y(1,:),'color','g','lineWidth',3);%solution
% axis([min(sol.x(1,:)),max(sol.x(1,:)),min(sol.y(1,:)),max(sol.y(1,:))])
% legend and label
% aa=legend({'$\sigma^s=2\times 10^7$', '$\sigma^s=10^7$', '$\sigma^s=5\times 10^6$'});
% set(aa, 'FontName', 'Helvetica','location','northeast','interpreter','latex');
% xlab=xlabel('$\zeta$');
% set(xlab,'FontName', 'Helvetica','interpreter','latex','FontSize', 20);
% ylab=ylabel('$\phi$');
% set(ylab,'FontName', 'Helvetica','interpreter','latex','FontSize', 20);
% plot([0.5 0.5],[min(sol.y(1,:)),max(sol.y(1,:))],'--k');
% set(gca, 'Position', [0.1 0.2 1 1/goldenphi]*0.8, 'FontSize', 25);
% hold off

% %_____________________________________________________ Chemical potential
    zeta=xmesh;
    phi=sol.y(1,:);
    phi_zeta=sol.y(2,:);
    phi_zetazeta=zeros(1,length(xmesh));
    dxmesh=xmesh(2)-xmesh(1);
    for jj=1:1:length(xmesh)-1
        phi_zetazeta(1,jj)=(phi_zeta(jj+1)-phi_zeta(jj))/dxmesh;
    end
    phi_zetazeta(1,end)=phi_zetazeta(1,length(xmesh)-1);

    % parameters
    n=1;
    R=8.314;
    T=300;
    F=96485.3321;
    E_teta=0;   
    k= 0.3; % kappa 
    alpha= 0.5; %
    W= 2.4; %
    epsilon_l=6578; %
    c0 = 1.0/14.89; %
    Cm_s=76.4; % dv = Csm/Clm = 5.5
    beta=10;
    epsilon_s=-34500; % mu_0s-mu_0N
    D_l=100; % M0
    Cm_l=14.4; % 
    L_eta= 0.001; % Ls
    L_sigma= 6.25; % L

    % non-constant
    h=zeta.^3.*(6*zeta.^2-15*zeta+10);
    eta=phi-E_teta;
    mu=-10*zeta;
    cLipos=(exp((mu-epsilon_l)/(R*T))./(1+exp((mu-epsilon_l)/(R*T)))).*(1-h);
    Fexp=exp((1-alpha)*n*F*eta/(R*T))-(cLipos/c0).*exp(-alpha*n*F*eta/(R*T));
    csarg=(mu-epsilon_s)/(R*T);
    cs=exp(csarg)./(1+exp(csarg));
    clarg=(mu-epsilon_l)/(R*T);
    cl=exp(clarg)./(1+exp(clarg));
    clprime=exp((epsilon_l-mu)/(R*T))./(R*T*(exp((epsilon_l-mu)/(R*T))+1).^2);
    hprime=zeta.^3.*(12*zeta - 15) + 3*zeta.^2.*(6*zeta.^2 - 15*zeta + 10);
    gprime=(33*zeta.*(zeta-1).^2)/25 + (33*zeta.^2.*(2*zeta-2))/50;
    c=cl.*(1-h)+cs.*h*(Cm_s/Cm_l);
    X=(exp(-(2*(epsilon_l-mu))/(R*T)).*(zeta.^3.*(6*zeta.^2-15*zeta+10)-1))./(R*T*(exp(-(epsilon_l-mu)/(R*T))+1).^2)-(exp(-(epsilon_l-mu)/(R*T)).*(zeta.^3.*(6*zeta.^2-15*zeta+10)-1))./(R*T*(exp(-(epsilon_l-mu)/(R*T))+1))+(Cm_s*zeta.^3.*exp(-(epsilon_s-mu)/(R*T)).*(6*zeta.^2-15*zeta+10))./(Cm_l*R*T*(exp(-(epsilon_s-mu)/(R*T))+1))-(Cm_s*zeta.^3.*exp(-(2*(epsilon_s-mu))/(R*T)).*(6*zeta.^2-15*zeta+10))./(Cm_l*R*T*(exp(-(epsilon_s-mu)/(R*T))+1).^2);
    zeta_y=2*beta*zeta.*(1-zeta);
    zeta_yy=-4*beta^2*zeta.*(1-zeta).*(2*zeta-1);
    phi_y=zeta_y.*phi_zeta;
    phi_yy=(zeta_y.^2).*phi_zetazeta+zeta_yy.*phi_zeta;
    mu_y=-10*zeta_y;
    mu_yy=-10*zeta_yy;
    P=D_l*(1-h).*cLipos/(R*T);
    P_y=D_l*(1-h).*(-2*hprime.*cl.*zeta_y+(1-h).*clprime.*mu_y)/(R*T);
    dmudt=(P_y.*mu_y+P.*mu_yy+n*F*P_y.*phi_y+n*F*P.*phi_yy-hprime.*(cs.*(Cm_s/Cm_l)-cl).*(-L_sigma*gprime+L_sigma*k*zeta_yy-L_eta*hprime.*Fexp))./X;
    Criterion=dmudt(end)-dmudt(1);
    avemu=sum(dmudt)*dxmesh/(zetamax-zetamin); % d^mu

   % % legend and label
   %  plot(zeta,dmudt,'color','g','lineWidth',3);
   %  hold on
   %  bb=legend({'$D^l=5\times 10^{-10}$', '$D^l=3.197\times 10^{-10}$', '$D^l= 10^{-10}$'});
   %  set(bb, 'FontName', 'Helvetica','location','northeast','interpreter','latex');
   %  xlab=xlabel('$\zeta$');
   %  set(xlab,'FontName', 'Helvetica','interpreter','latex','FontSize', 20);
   %  ylab2=ylabel('$\partial_t \mu$');
   %  set(ylab2,'FontName', 'Helvetica','interpreter','latex','FontSize', 20);
   %  set(gca, 'Position', [0.1 0.2 1 1/goldenphi]*0.8, 'FontSize', 25);
   % hold off


% % ___________________________________________________________ Phase order
dzetadt=-L_sigma*gprime+L_sigma*k*zeta_yy-L_eta*hprime.*Fexp;
averate=sum(dzetadt)*dxmesh/(zetamax-zetamin); % d^zeta
%save('conduct_greenval','dzetadt');

  % % legend and label
  %   plot(zeta,dzetadt,'color','r','lineWidth',3);
  %   hold on
  %   bb=legend({'$D^l=5\times 10^{-10}$', '$D^l=3.197\times 10^{-10}$', '$D^l= 10^{-10}$'});
  %   set(bb, 'FontName', 'Helvetica','location','northeast','interpreter','latex');
  %   xlab=xlabel('$\zeta$');
  %   set(xlab,'FontName', 'Helvetica','interpreter','latex','FontSize', 20);
  %   ylab2=ylabel('$\partial_t \zeta$');
  %   set(ylab2,'FontName', 'Helvetica','interpreter','latex','FontSize', 20);
  % set(gca, 'Position', [0.1 0.2 1 1/goldenphi]*0.8, 'FontSize', 25);
  % hold off


function dydx = bvpfcn(zeta,y)
    % parameters
    n=1;
    R=8.314;
    T=300;
    F=96485.3321;
    E_teta=0;   
    k= 0.3; % kappa 
    alpha= 0.5; %
    W= 2.4; %
    epsilon_l=6578; %
    c0 = 1.0/14.89; %
    Cm_s=76.4; % dv = Csm/Clm = 5.5
    beta=10;
    L_eta= 0.001; % Ls
    L_sigma= 6.25; % L 
    sigma_s=10^7; % S1
    sigma_l=1.19; % S2

    % non-constant
    h=zeta.^3.*(6*zeta.^2-15*zeta+10);
    sigma=(sigma_s-sigma_l)*h+sigma_l;
    eta=y(1)-E_teta;
    mu=-10*zeta;
    cLipos=(exp((mu-epsilon_l)/(R*T))./(1+exp((mu-epsilon_l)/(R*T)))).*(1-h);
    Fexp=exp((1-alpha)*n*F*eta/(R*T))-(cLipos/c0)*exp(-alpha*n*F*eta/(R*T)); %q=Fexp
    
    % ODE coeffs:
    A=sigma*zeta*(1-zeta); % original
    B=30*(sigma_s-sigma_l)*zeta^3*(1-zeta)^3-sigma*(2*zeta-1); % original
    FF=(n*F*Cm_s/(2*beta^2))*(L_sigma*(2*zeta-1)*(W-2*beta^2*k)-15*L_eta*zeta*(1-zeta)*Fexp); % original

    dydx = [y(2);
           (FF-B*y(2))/A];
end

function res = bcfcn(ya,yb)

    % % Linear boundary conditions:
    % zetamax=0.7;
    % zetamin=0.3;
    % phi_e=-0.45;
    % phi1=phi_e*(zetamax);
    % phi0=phi_e*(zetamin);

    % %______valley
    phi1=-0.5;
    phi0=-0.3;
    % %______tip
    % phi1=-0.6;
    % phi0=-0.1;

    res = [ya(1)-phi0;
           yb(1)-phi1];
end

function g = guess(zeta)

    % % Linear initial guess solution:
    % phi_e=-0.45;
    % g = [phi_e*zeta;
    %       phi_e*ones(1,length(zeta))];

    % %______valley
    phi1=-0.5;
    phi0=-0.3;
    % %______tip
    % phi1=-0.6;
    % phi0=-0.1;
    g = [((phi1-phi0)/0.4)*(zeta-0.3)+phi0;
          ((phi1-phi0)/0.4)*ones(1,length(zeta))];

end


