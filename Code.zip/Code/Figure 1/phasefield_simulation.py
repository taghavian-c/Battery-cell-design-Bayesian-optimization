"""
A complete siulation of the phase-field model with flexible voltage levels and time horizon.
"""

from fenics import *
from datetime import datetime
import matplotlib.pyplot as plt
from phasefield_env import phenv
from Roughness import CVD
import numpy as np 
import scipy.io

# Start message
print("Started at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))

# Mesh dimension and size
lox= 200
loy= 100
nx, ny = 400, 200

# Mesh and function space
mesh = RectangleMesh(Point(0, 0), Point(lox, loy), nx, ny)
P1 = FiniteElement('P', triangle, 1)
V = FunctionSpace(mesh, MixedElement([P1,P1,P1]))

# Trial and  test functions
v_1, v_2, v_3 = TestFunctions(V)

# previous and current solutions
u = Function(V)                # current
u_n = Function(V)               # previous

# Initial conditions:
ruido = Expression('0.175*exp(-0.1*pow(x[1]-50.,2.0))', degree=3)
u_init = Expression(('0.5*(1.0-1.0*tanh((x[0]-20.0+ruido)*2))','x[0] < (20.0) ? -10.0 : 0.0','-0.225*(1.0-tanh((x[0]-20.0+ruido)*2))'), degree=3, ruido=ruido)
u_old=u_init

# simulation time and voltage
Tfin=0.04 # the time length of each envstep
Voltrange=[-0.45]*1500 # (-) plating, (+) stripping
num_envsteps=len(Voltrange)
totaltime=np.zeros((1,num_envsteps))
totaltime[0,:]=np.arange(0,num_envsteps*Tfin,Tfin)
Taxis=totaltime[0,:]
voltage=Voltrange[0]
num_plot=0
Rough=np.zeros((1,num_envsteps))

for n in range(num_envsteps):

    # Timestamp
    print("step = ", n, "timestamp =", datetime.fromtimestamp(datetime.timestamp(datetime.now())))
    voltage=Voltrange[n] # the new action (control input). 
    u=phenv(u_old,voltage,Tfin) # one step
    
    # Output roughness
    [cha,val,den]=CVD(u)
    Rough[0,n]=den-val
    
    # keep saving
    Raxis=Rough[0,:]
    matdic = {"roughness": Raxis, "time": Taxis}
    scipy.io.savemat('Backup_Bopt_Outputs.mat', matdic)
    

    # Plot
    if (n==0 or n==int(round(num_envsteps/2)) or n==int(num_envsteps-1)):

        xi_t, w_t, phi_t = u.split()
        plt.figure(1)
        plt.subplot(3, 3, int(num_plot+1))
        plt.colorbar(plot(xi_t))
        plt.subplot(3, 3, int(num_plot+4))
        plt.colorbar(plot(w_t))
        plt.subplot(3, 3, int(num_plot+7))
        plt.colorbar(plot(phi_t))
        plt.xlabel('$x$')
        plt.ylabel('$y$')       
        num_plot+=1
        
        # save u
        output_file = HDF5File(mesh.mpi_comm(), f"u{n}.h5", "w")
        output_file.write(u, "solution")
        output_file.close()
        
    
    # Update
    u_old=u # update the current state
    


# output plots
plt.figure(1)
plt.savefig(f'PDE.png')

plt.figure(2)
Raxis=Rough[0,:]
plt.plot(Taxis,Raxis)
plt.xlabel("time")
plt.title('Surface roughness')
plt.savefig(f'roughness.png')

# save mat files
matdic = {"roughness": Raxis, "time": Taxis}
scipy.io.savemat('Outputs.mat', matdic)

# End message
print("Completed at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))


