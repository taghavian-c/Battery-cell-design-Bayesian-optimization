"""
Calculates the amount of charge and the surface roughness
"""

from fenics import *
from boxfield import *
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np

def CVD(u):
    
    # Mesh dimension and size
    lox= 200
    loy= 100
    nx, ny = 400, 200 
    
    Csm=7.64e4**(2/3) # unit: mol/m2. Converted to 2D.
    n=1 #charge valence
    F=9.648533e4 # unit: C/mol. Faraday constant
    
    xi_t, w_t, phi_t = u.split(deepcopy=True)
    u_box = FEniCSBoxField(xi_t, (nx, ny))
    
    x = u_box.grid.coor[X]
    delx = x[1] - x[0]
    y = u_box.grid.coor[Y]
    dely = y[1] - y[0]
    delxy=delx*dely*1e-12 # unit:m^2   
    
    
    Usumz=np.zeros((1,u_box.values.shape[1]))
    Usumzh=np.zeros((1,u_box.values.shape[1]))
    
    # Iterate over 2D mesh points (i, j)
    for j in range(u_box.values.shape[1]): # Y direction
        #using zeta
        Usumz[0,j]=np.sum(u_box.values[:,j])*delx*1e-6 # unit: m
        #using the function h(zeta):
        hzeta= np.power(u_box.values[:,j],3)*(6.0*np.power(u_box.values[:,j],2) -15.0*u_box.values[:,j] + 10.0)
        Usumzh[0,j]=np.sum(hzeta*Csm*delxy)
    
    # charge
    chamol=np.sum(Usumzh) # unit: mol
    cha=chamol*n*F # unit: C
    
    # valley level
    val=np.min(Usumz) # unit: m
    
    # dendrite level    
    den=np.max(Usumz) # unit: m
    
    return [cha,val,den]

