"""
Simulate the phase field model for a short time (one step)
"""

from fenics import *
from datetime import datetime
import matplotlib.pyplot as plt

def phenv(u_old,voltage,Tfin):
    
    # Start message
    print("Starting one envstep at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))
    
    # Mesh dimension and size
    lox= 200
    loy= 100
    nx, ny = 400, 200 
    
    # Applied voltage
    phie = voltage
    
    # Normalized Parameters 
    L = Constant(1)             #(for 2a) L_sigma
    #L = Constant(20)           #(for 2b) L_sigma
    #______________________
    kappa = Constant(0.3)       #kappa
    Ls = Constant(0.001)        #L_eta
    alpha = Constant(0.5)       #alpha
    AA = Constant(38.69)        #nF/RT
    W = Constant(2.4)           #W
    es = Constant(-13.8)        #e^s
    el = Constant(2.631)        #e^l
    A = Constant(1.0)           #R*T/R*T
    c0 = Constant(1.0/14.89)    #c_0
    dv = Constant(8.25)         #Csm/Clm
    M0 = Constant(158.95)       #D^l                               
    S1 = Constant(1500000)      #sigma^s                             
    S2 = Constant(0.595)        #sigma^l                        
    ft2 = Constant(0.0074)      #nFCsm
    
    # Mesh and function space
    mesh = RectangleMesh(Point(0, 0), Point(lox, loy), nx, ny)
    P1 = FiniteElement('P', triangle, 1)
    V = FunctionSpace(mesh, MixedElement([P1,P1,P1]))
    
    # Trial and  test functions
    v_1, v_2, v_3 = TestFunctions(V)
    
    # previous and at current solutions
    u = Function(V)                # current
    u_n = Function(V)               # previous
    
    # Split the solution
    xi, w, phi = split(u)
    xi_n, w_n, phi_n = split(u_n)  
    
    # initial conditions
    u_init=u_old
    u.interpolate(u_init)
    u_n.interpolate(u_init)
        
    # Boundary conditions   
    # Boundaries y=0, y=Ly
    def boundary0(x, on_boundary):
        return on_boundary and near(x[0], 0)
    def boundaryL(x, on_boundary):
        return on_boundary and near(x[0], lox)
    
    # Boundary conditions for xi
    bc_xi1 = DirichletBC(V.sub(0), Constant(1.0), boundary0)
    bc_xi2 = DirichletBC(V.sub(0), Constant(0.0), boundaryL)
    
    # Boundary conditions for mu
    bc_c2 = DirichletBC(V.sub(1), Constant(0.0), boundaryL)
    
    # Boundary conditions for phi
    bc_phi1 = DirichletBC(V.sub(2), Constant(phie), boundary0)
    bc_phi2 = DirichletBC(V.sub(2), Constant(0.0), boundaryL)
    
    # Gather all boundary conditions in a variable
    bcs = [bc_xi1, bc_xi2, bc_c2, bc_phi1, bc_phi2 ] # Dirichlet
    
    # Variational problem
    # Switching Function Material
    def h(_x):
        return _x**3*(Constant(6.0)*_x**2 - Constant(15.0)*_x + Constant(10.0))
    def dh(_x):
        return Constant(30.0)*_x*_x*(_x-Constant(1.0))*(_x-Constant(1.0))
    
    # Barrier Function Material
    def g(_x):
        return W*_x**2.0*(Constant(1.0) - _x)**2
    def dg(_x):
        return W*Constant(2.0)*(_x * (Constant(1.0) - _x) ** 2 - (Constant(1.0) - _x) * _x ** 2)
    
    # Concentration
    def cl(_x):
        return exp((_x-el)/A)/(Constant(1.0)+exp((_x-el)/A))
    def dcldw(_x):
        return exp((_x+el)/A)/(A*(exp(_x/A)+exp(el/A))**2)
    def cs(_x):
        return exp((_x-es)/A)/(Constant(1.0)+exp((_x-es)/A))
    def dcsdw(_x):
        return exp((_x+es)/A)/(A*(exp(_x/A)+exp(es/A))**2)
    
    # Susceptibility factor
    def chi(_xi,_w):
        return dcldw(_w)*(Constant(1.0)-h(_xi))+dcsdw(_w)*h(_xi)*dv
    
    # Mobility defined by D*c/(R*T), whereR*T is normalized by the chemical potential
    # M0*(1-h) is the effective diffusion coefficient; cl*(1-h) is the ion concentration
    def D(_xi,_w):
        return M0*(Constant(1.0)-h(_xi))*cl(_w)*(Constant(1.0)-h(_xi))
    
    # Feature of diffusion
    def ft(_w):
        return cs(_w)*dv-cl(_w)
    
    # Effective conductivity, Derivative Parsed Material
    def Le1(_xi):
        return S1*h(_xi)+S2*(Constant(1.0)-h(_xi))
    
    
    # Simulation time
    t = 0.0
    Tf = Tfin
    dt = 0.04
    num_steps = int(Tf/dt)
    k = Constant(dt)
      
    # Define variational problem
    F1 = (xi-xi_n)/k*v_1*dx + L*kappa*dot(grad(xi),grad(v_1))*dx + L*dg(xi)*v_1*dx + Ls*(exp(phi*AA/Constant(2.0))-Constant(14.89)*cl(w)*(Constant(1.0)-h(xi))*exp(-phi*AA/Constant(2.0)))*dh(xi)*v_1*dx
    F2 = chi(xi,w)*(w-w_n)/k*v_2*dx + D(xi, w)*dot(grad(w),grad(v_2))*dx + D(xi, w)*AA*dot(grad(phi),grad(v_2))*dx + (h(xi)-h(xi_n))/k*ft(w)*v_2*dx
    F3 = Le1(xi)*dot(grad(phi),grad(v_3))*dx + ft2*(xi-xi_n)/k*v_3*dx
    F = F1 + F2 + F3
    
    # Jacobian
    J = derivative(F,u)
    
    # Time step
    for n in range(num_steps):
    
        # Update time
        t+=dt
    
        # Solve problem
        solve(F == 0, u, bcs, J=J, solver_parameters={"newton_solver":{"absolute_tolerance":1.0e-2, "relative_tolerance":1.0e-2, "maximum_iterations":100}})
    
        # Update previous solution
        u_n.assign(u)
        
        set_log_level(LogLevel.INFO)
    
    # End message
    print("Completed one step at ", datetime.fromtimestamp(datetime.timestamp(datetime.now())))

    return u

